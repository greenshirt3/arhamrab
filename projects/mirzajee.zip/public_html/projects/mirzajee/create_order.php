<?php
session_start();
include 'config.php';
if (!isset($_SESSION['admin_logged_in'])) header("Location: login.php");

// Handle Form Submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = cleanInput($_POST['name']);
    $phone = cleanInput($_POST['phone']);
    $cnic = cleanInput($_POST['cnic']);
    $service = cleanInput($_POST['service']);
    
    // Financials
    $fee = cleanInput($_POST['fee']); // Total Fee
    $paid = cleanInput($_POST['paid']); // Paid Now
    
    // Generate Tracking ID (e.g., MZ-5921)
    $tracking_id = "MZ-" . rand(1000, 9999);

    // Insert Order
    $stmt = $conn->prepare("INSERT INTO orders (tracking_id, customer_name, phone, cnic, service_id, total_fee, paid_amount) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssidd", $tracking_id, $name, $phone, $cnic, $service, $fee, $paid);
    
    if ($stmt->execute()) {
        $last_id = $conn->insert_id;
        
        // Also Record this as a Transaction in the Ledger automatically
        if($paid > 0) {
            $desc = "Payment for Order #$tracking_id";
            $conn->query("INSERT INTO transactions (type, category, amount, description, order_id) VALUES ('Income', 'Order Payment', '$paid', '$desc', '$last_id')");
        }

        // Redirect to Print Receipt
        header("Location: receipt.php?id=$last_id");
        exit();
    } else {
        $error = "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>New Application Entry</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    
    <script>
        function updatePrice() {
            var select = document.getElementById('serviceSelect');
            var price = select.options[select.selectedIndex].getAttribute('data-price');
            document.getElementById('feeInput').value = price;
        }
    </script>
</head>
<body class="bg-gray-100 font-sans flex text-gray-800">

    <?php include 'admin_sidebar.php'; ?>

    <div class="flex-1 p-8 overflow-y-auto h-screen">
        <h1 class="text-3xl font-bold text-gray-800 mb-2">New Application</h1>
        <p class="text-gray-500 mb-8">Create a new order and generate a receipt.</p>

        <div class="bg-white rounded-xl shadow-lg p-8 max-w-4xl border-t-4 border-[#0F3D3E]">
            
            <?php if(isset($error)) echo "<p class='text-red-500 mb-4'>$error</p>"; ?>

            <form method="POST">
                <h3 class="font-bold text-gray-700 border-b pb-2 mb-4 uppercase text-xs tracking-wider">Customer Details</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                        <label class="block text-gray-600 text-sm font-bold mb-2">Full Name</label>
                        <input type="text" name="name" required class="w-full border border-gray-300 p-3 rounded focus:outline-none focus:border-green-600" placeholder="e.g. Ali Khan">
                    </div>
                    <div>
                        <label class="block text-gray-600 text-sm font-bold mb-2">Phone Number</label>
                        <input type="text" name="phone" required class="w-full border border-gray-300 p-3 rounded focus:outline-none focus:border-green-600" placeholder="0300-1234567">
                    </div>
                    <div>
                        <label class="block text-gray-600 text-sm font-bold mb-2">CNIC (Optional)</label>
                        <input type="text" name="cnic" class="w-full border border-gray-300 p-3 rounded focus:outline-none focus:border-green-600" placeholder="34201-xxxxxxx-x">
                    </div>
                </div>

                <h3 class="font-bold text-gray-700 border-b pb-2 mb-4 uppercase text-xs tracking-wider mt-8">Service & Payment</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div class="md:col-span-2">
                        <label class="block text-gray-600 text-sm font-bold mb-2">Select Service</label>
                        <select name="service" id="serviceSelect" onchange="updatePrice()" class="w-full border border-gray-300 p-3 rounded focus:outline-none focus:border-green-600 bg-white">
                            <option value="" data-price="0">-- Select Service --</option>
                            <?php
                            $res = $conn->query("SELECT * FROM services ORDER BY name_en ASC");
                            while($r = $res->fetch_assoc()){
                                echo "<option value='".$r['id']."' data-price='".$r['price']."'>".$r['name_en']." (Rs. ".number_format($r['price']).")</option>";
                            }
                            ?>
                        </select>
                    </div>
                    
                    <div>
                        <label class="block text-gray-600 text-sm font-bold mb-2">Total Fee (Agreed)</label>
                        <div class="relative">
                            <span class="absolute left-3 top-3 text-gray-500">Rs.</span>
                            <input type="number" name="fee" id="feeInput" value="0" class="w-full border border-gray-300 p-3 pl-10 rounded focus:outline-none focus:border-green-600 font-bold text-gray-800">
                        </div>
                    </div>
                    
                    <div>
                        <label class="block text-gray-600 text-sm font-bold mb-2">Advance Payment (Received)</label>
                        <div class="relative">
                            <span class="absolute left-3 top-3 text-gray-500">Rs.</span>
                            <input type="number" name="paid" value="0" class="w-full border border-gray-300 p-3 pl-10 rounded focus:outline-none focus:border-green-600 font-bold text-green-700">
                        </div>
                    </div>
                </div>

                <div class="flex justify-end gap-4 mt-8 pt-4 border-t">
                    <a href="admin_orders.php" class="px-6 py-3 rounded text-gray-600 hover:bg-gray-100">Cancel</a>
                    <button type="submit" class="bg-[#0F3D3E] text-white px-8 py-3 rounded shadow hover:bg-green-900 transition font-bold flex items-center gap-2">
                        <i class="fas fa-save"></i> Save & Print Receipt
                    </button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>