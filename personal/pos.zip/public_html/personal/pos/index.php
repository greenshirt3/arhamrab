<?php
$password = "2733"; // Access Code
session_start();
if (isset($_POST['p']) && $_POST['p'] == $password) { $_SESSION['logged_in'] = true; }
if (isset($_GET['out'])) { session_destroy(); header("Location: index.php"); exit; }
if (!isset($_SESSION['logged_in'])): ?>
<!DOCTYPE html><body style="background:#0f172a;display:flex;justify-content:center;align-items:center;height:100vh;font-family:sans-serif">
<form method="post" style="background:white;padding:40px;border-radius:10px;text-align:center;width:350px;box-shadow:0 10px 25px rgba(0,0,0,0.1)">
<h2 style="margin:0 0 20px;color:#0f172a;font-weight:800">ARHAM<span style="color:#06b6d4">ERP</span></h2>
<input type="password" name="p" placeholder="Enter PIN" style="width:100%;padding:12px;margin-bottom:15px;border:1px solid #ddd;border-radius:6px;outline:none" required autofocus>
<button style="width:100%;padding:12px;background:#0f172a;border:none;color:white;font-weight:bold;border-radius:6px;cursor:pointer;transition:0.3s">ACCESS SYSTEM</button>
</form></body></html><?php exit; endif; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Arham ERP - Professional Invoicing</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>
    
    <style>
        :root { --blue: #0f172a; --cyan: #06b6d4; --light: #f1f5f9; --border: #e2e8f0; }
        body { background: var(--light); font-family: 'Inter', 'Segoe UI', sans-serif; display: flex; overflow-x: hidden; font-size: 14px; }
        
        /* SIDEBAR */
        #sidebar { width: 260px; min-width: 260px; background: var(--blue); color: #fff; min-height: 100vh; transition: 0.3s; z-index: 1000; }
        #sidebar .brand { padding: 25px; font-size: 1.5rem; font-weight: 800; border-bottom: 1px solid rgba(255,255,255,0.05); letter-spacing: 0.5px; }
        #sidebar ul { list-style: none; padding: 15px 10px; margin: 0; }
        #sidebar a { display: flex; align-items: center; padding: 12px 15px; color: #94a3b8; text-decoration: none; font-weight: 500; border-radius: 8px; margin-bottom: 5px; transition: 0.2s; }
        #sidebar a:hover, #sidebar a.active { background: var(--cyan); color: #fff; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        #sidebar i { width: 25px; font-size: 1.1rem; }
        .sb-label { font-size: 0.75rem; text-transform: uppercase; color: #64748b; padding: 20px 20px 10px; font-weight: 700; letter-spacing: 1px; }

        /* CONTENT */
        #content { flex-grow: 1; padding: 0; transition: 0.3s; position: relative; max-width: 100%; }
        .topbar { background: #fff; padding: 15px 30px; box-shadow: 0 1px 2px rgba(0,0,0,0.05); display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid var(--border); }
        .main-p { padding: 30px; height: calc(100vh - 70px); overflow-y: auto; }
        
        /* MODULES */
        .module { display: none; animation: fadeIn 0.3s ease-in-out; }
        .module.active { display: block; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(5px); } to { opacity: 1; transform: translateY(0); } }

        /* PROFESSIONAL INVOICE STYLES (A4) */
        .invoice-paper {
            background: white; width: 210mm; min-height: 297mm; margin: 0 auto; padding: 15mm;
            box-shadow: 0 0 30px rgba(0,0,0,0.1); position: relative; color: #333;
        }
        .inv-header { display: flex; justify-content: space-between; border-bottom: 2px solid var(--blue); padding-bottom: 20px; margin-bottom: 30px; }
        .inv-logo { font-size: 28px; font-weight: 900; color: var(--blue); text-transform: uppercase; }
        .inv-meta { text-align: right; }
        .inv-meta h1 { margin: 0; font-size: 40px; color: #cbd5e1; font-weight: 800; letter-spacing: 2px; }
        .inv-grid { display: flex; justify-content: space-between; margin-bottom: 40px; }
        .inv-to h5 { color: #64748b; font-size: 12px; text-transform: uppercase; font-weight: 700; margin-bottom: 10px; }
        .inv-table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
        .inv-table th { background: #f8fafc; color: #475569; font-weight: 700; text-transform: uppercase; font-size: 11px; padding: 12px; border-bottom: 2px solid #e2e8f0; text-align: left; }
        .inv-table td { padding: 12px; border-bottom: 1px solid #e2e8f0; color: #334155; }
        .inv-table tr:last-child td { border-bottom: none; }
        .inv-total-box { width: 250px; margin-left: auto; background: #f8fafc; border-radius: 8px; padding: 20px; }
        .inv-row { display: flex; justify-content: space-between; margin-bottom: 8px; font-size: 13px; }
        .inv-row.final { font-size: 16px; font-weight: 800; color: var(--blue); border-top: 2px solid #cbd5e1; padding-top: 10px; margin-top: 10px; }
        .status-stamp {
            position: absolute; top: 200px; right: 50px; font-size: 60px; font-weight: 900;
            opacity: 0.1; transform: rotate(-15deg); text-transform: uppercase; border: 5px solid; padding: 10px 30px; border-radius: 10px;
        }
        .status-paid { color: #10b981; border-color: #10b981; }
        .status-unpaid { color: #ef4444; border-color: #ef4444; }

        /* BUILDER STYLES */
        .builder-card { background: #fff; border-radius: 12px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); overflow: hidden; border: 1px solid var(--border); }
        .b-header { background: #f8fafc; padding: 15px 25px; border-bottom: 1px solid var(--border); display: flex; justify-content: space-between; align-items: center; }
        .b-body { padding: 25px; }
        
        /* POS & UTILS */
        .p-card { background: #fff; border: 1px solid var(--border); border-radius: 8px; padding: 15px; cursor: pointer; transition: 0.2s; text-align: center; }
        .p-card:hover { border-color: var(--cyan); box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1); }
        .product-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 15px; }
        
        /* PRINT MODE */
        @media print {
            #sidebar, .topbar, .no-print { display: none !important; }
            .main-p { padding: 0; overflow: visible; height: auto; }
            .invoice-paper { box-shadow: none; margin: 0; width: 100%; }
            body { background: white; }
        }
    </style>
</head>
<body>

    <nav id="sidebar">
        <div class="brand">ARHAM <span style="color:var(--cyan)">ERP</span></div>
        <div class="sb-label">Management</div>
        <ul>
            <li><a href="#" onclick="nav('dashboard')" class="active"><i class="fas fa-chart-pie"></i> Dashboard</a></li>
            <li><a href="#" onclick="nav('builder')"><i class="fas fa-file-invoice-dollar"></i> Invoice Builder</a></li>
            <li><a href="#" onclick="nav('invoices')"><i class="fas fa-history"></i> Invoice History</a></li>
            <li><a href="#" onclick="nav('pos')"><i class="fas fa-cash-register"></i> Quick Sale (POS)</a></li>
        </ul>
        <div class="sb-label">Operations</div>
        <ul>
            <li><a href="#" onclick="nav('jobs')"><i class="fas fa-print"></i> Printing Jobs</a></li>
            <li><a href="#" onclick="nav('purchases')"><i class="fas fa-truck-loading"></i> Purchase / Stock</a></li>
            <li><a href="#" onclick="nav('inventory')"><i class="fas fa-boxes"></i> Inventory</a></li>
            <li><a href="#" onclick="nav('expenses')"><i class="fas fa-receipt"></i> Expenses</a></li>
            <li><a href="#" onclick="nav('people')"><i class="fas fa-users"></i> Contacts</a></li>
        </ul>
        <div style="margin-top:auto; padding: 20px;">
            <a href="?out=true" style="background:rgba(255,255,255,0.1); justify-content:center"><i class="fas fa-power-off me-2"></i> Logout</a>
        </div>
    </nav>

    <div id="content">
        <div class="topbar no-print">
            <h5 class="m-0 fw-bold text-dark" id="pageTitle">Dashboard</h5>
            <div class="d-flex align-items-center gap-3">
                <button class="btn btn-dark btn-sm rounded-pill px-4" onclick="nav('builder')">+ Create Invoice</button>
                <div class="bg-light rounded-circle p-2 border"><i class="fas fa-user text-muted"></i></div>
            </div>
        </div>

        <div class="main-p">
            
            <div id="dashboard" class="module active">
                <div class="row g-4 mb-4">
                    <div class="col-md-3">
                        <div class="builder-card p-4">
                            <h6 class="text-muted fw-bold text-uppercase small">Total Revenue</h6>
                            <h2 class="fw-bold m-0" id="d_revenue">0</h2>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="builder-card p-4">
                            <h6 class="text-muted fw-bold text-uppercase small">Receivables (Due)</h6>
                            <h2 class="fw-bold m-0 text-danger" id="d_due">0</h2>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="builder-card p-4">
                            <h6 class="text-muted fw-bold text-uppercase small">Pending Jobs</h6>
                            <h2 class="fw-bold m-0 text-warning" id="d_jobs">0</h2>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="builder-card p-4">
                            <h6 class="text-muted fw-bold text-uppercase small">Inventory Items</h6>
                            <h2 class="fw-bold m-0 text-primary" id="d_stock">0</h2>
                        </div>
                    </div>
                </div>
                <div class="builder-card p-4">
                    <h5 class="mb-3 fw-bold">Recent Invoices</h5>
                    <table class="table table-hover">
                        <thead class="table-light"><tr><th>#</th><th>Date</th><th>Customer</th><th>Amount</th><th>Due</th><th>Status</th></tr></thead>
                        <tbody id="dashTable"></tbody>
                    </table>
                </div>
            </div>

            <div id="builder" class="module">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="builder-card">
                            <div class="b-header">
                                <h5 class="m-0 fw-bold"><i class="fas fa-pen-nib me-2 text-primary"></i> Create Professional Invoice</h5>
                                <div>
                                    <button class="btn btn-outline-secondary btn-sm" onclick="resetBuilder()">Reset</button>
                                    <button class="btn btn-primary btn-sm px-4" onclick="saveInvoice()">Save & View</button>
                                </div>
                            </div>
                            <div class="b-body">
                                <div class="row g-3 mb-4">
                                    <div class="col-md-4">
                                        <label class="form-label fw-bold">Customer</label>
                                        <div class="input-group">
                                            <select id="bCust" class="form-select"></select>
                                            <button class="btn btn-outline-secondary" onclick="promptAddPerson('cust')">+</button>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                        <label class="form-label fw-bold">Invoice No</label>
                                        <input type="text" id="bNo" class="form-control bg-light" readonly>
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label fw-bold">Issue Date</label>
                                        <input type="date" id="bDate" class="form-control">
                                    </div>
                                    <div class="col-md-3">
                                        <label class="form-label fw-bold">Due Date</label>
                                        <input type="date" id="bDue" class="form-control">
                                    </div>
                                </div>

                                <div class="table-responsive mb-3">
                                    <table class="table table-bordered align-middle">
                                        <thead class="table-light">
                                            <tr>
                                                <th width="40%">Item / Description</th>
                                                <th width="10%">Qty</th>
                                                <th width="15%">Rate</th>
                                                <th width="15%">Tax</th>
                                                <th width="15%">Total</th>
                                                <th width="5%"></th>
                                            </tr>
                                        </thead>
                                        <tbody id="bRows"></tbody>
                                    </table>
                                </div>
                                <button class="btn btn-light border text-primary fw-bold w-100 mb-4" onclick="addInvRow()">+ Add Line Item</button>

                                <div class="row">
                                    <div class="col-md-6">
                                        <label class="form-label fw-bold">Notes / Terms</label>
                                        <textarea id="bNotes" class="form-control" rows="4" placeholder="Thank you for your business. Terms: Net 30."></textarea>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="bg-light p-3 rounded">
                                            <div class="d-flex justify-content-between mb-2"><span>Subtotal:</span><span class="fw-bold" id="bSub">0.00</span></div>
                                            <div class="d-flex justify-content-between mb-2 text-danger"><span>Tax Total:</span><span class="fw-bold" id="bTax">0.00</span></div>
                                            <div class="d-flex justify-content-between mb-2 align-items-center">
                                                <span>Discount:</span>
                                                <input type="number" id="bDisc" class="form-control form-control-sm w-25 text-end" value="0" oninput="calcInvTotals()">
                                            </div>
                                            <hr>
                                            <div class="d-flex justify-content-between mb-3 fs-5 fw-bold"><span>Grand Total:</span><span id="bTotal">0.00</span></div>
                                            <div class="d-flex justify-content-between align-items-center mb-2 text-success">
                                                <span>Amount Paid:</span>
                                                <input type="number" id="bPaid" class="form-control form-control-sm w-25 text-end" value="0" oninput="calcInvTotals()">
                                            </div>
                                            <div class="d-flex justify-content-between text-danger fw-bold"><span>Balance Due:</span><span id="bBal">0.00</span></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="viewer" class="module">
                <div class="mb-3 d-flex gap-2 justify-content-center no-print">
                    <button class="btn btn-secondary rounded-pill px-4" onclick="nav('invoices')"><i class="fas fa-arrow-left"></i> Back</button>
                    <button class="btn btn-dark rounded-pill px-4" onclick="window.print()"><i class="fas fa-print"></i> Print</button>
                    <button class="btn btn-success rounded-pill px-4" onclick="shareWhatsapp()"><i class="fab fa-whatsapp"></i> Share</button>
                </div>
                <div id="printArea" class="invoice-paper">
                    </div>
            </div>

            <div id="invoices" class="module">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h3>Invoice History</h3>
                    <div class="input-group w-25">
                        <span class="input-group-text"><i class="fas fa-search"></i></span>
                        <input type="text" class="form-control" id="invSearch" placeholder="Search..." onkeyup="renderInvList()">
                    </div>
                </div>
                <div class="builder-card p-0">
                    <table class="table table-hover m-0 align-middle">
                        <thead class="table-light"><tr><th class="p-3">Inv #</th><th>Date</th><th>Customer</th><th>Total</th><th>Paid</th><th>Due</th><th>Status</th><th class="text-end p-3">Action</th></tr></thead>
                        <tbody id="invList"></tbody>
                    </table>
                </div>
            </div>

            <div id="pos" class="module">
                <div class="row h-100">
                    <div class="col-lg-8">
                        <div class="bg-white p-3 rounded shadow-sm mb-3 d-flex gap-2">
                            <input type="text" id="posSearch" class="form-control rounded-pill px-3" placeholder="Search Item..." onkeyup="renderPosGrid()">
                        </div>
                        <div class="product-grid" id="posGrid"></div>
                    </div>
                    <div class="col-lg-4">
                        <div class="builder-card h-100 d-flex flex-column">
                            <div class="p-3 bg-dark text-white d-flex justify-content-between rounded-top">
                                <span class="fw-bold">Current Sale</span>
                                <span class="badge bg-danger rounded-pill" id="posCount">0</span>
                            </div>
                            <div class="flex-grow-1 p-3" style="overflow-y:auto; max-height:50vh" id="posCart"></div>
                            <div class="p-3 bg-light border-top">
                                <select id="posCust" class="form-select mb-2"></select>
                                <div class="d-flex justify-content-between fw-bold h4 mb-3"><span>Total:</span><span id="posTotal">0</span></div>
                                <button class="btn btn-primary w-100 py-2 fw-bold" onclick="processPOS()">COMPLETE SALE</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div id="inventory" class="module">
                <div class="d-flex justify-content-between mb-3"><h3>Inventory</h3> <button class="btn btn-primary" onclick="promptAddItem()">+ New Item</button></div>
                <div class="builder-card"><table class="table table-hover m-0"><thead class="table-light"><tr><th>ID</th><th>Name</th><th>Category</th><th>Stock</th><th>Price</th></tr></thead><tbody id="invTable"></tbody></table></div>
            </div>
            
            <div id="expenses" class="module">
                <h3>Expense Tracker</h3>
                <form onsubmit="addExpense(event)" class="d-flex gap-2 mb-3 bg-white p-3 rounded shadow-sm"><input type="text" id="expDesc" class="form-control" placeholder="Description" required><input type="number" id="expAmt" class="form-control w-25" placeholder="Amount" required><button class="btn btn-danger">Record</button></form>
                <div class="builder-card"><ul id="expList" class="list-group list-group-flush"></ul></div>
            </div>

            <div id="people" class="module">
                <h3>Contacts</h3>
                <div class="row g-4">
                    <div class="col-md-6"><div class="builder-card p-3"><h5>Customers</h5><ul id="custList" class="list-group"></ul></div></div>
                    <div class="col-md-6"><div class="builder-card p-3"><h5>Suppliers</h5><ul id="suppList" class="list-group"></ul></div></div>
                </div>
            </div>

            <div id="jobs" class="module">
                <div class="d-flex justify-content-between mb-3"><h3>Job Tickets</h3> <button class="btn btn-primary" onclick="newJob()">+ New Job</button></div>
                <div class="row g-3" id="jobBoard"></div>
            </div>

            <div id="purchases" class="module">
                <h3>Stock Purchase</h3>
                <div class="builder-card p-4 mb-3">
                    <form onsubmit="addPurchase(event)" class="row g-3">
                        <div class="col-md-4"><select id="purItem" class="form-select"></select></div>
                        <div class="col-md-3"><input type="number" id="purQty" class="form-control" placeholder="Qty"></div>
                        <div class="col-md-3"><input type="number" id="purCost" class="form-control" placeholder="Total Cost"></div>
                        <div class="col-md-2"><button class="btn btn-success w-100">Add</button></div>
                    </form>
                </div>
                <table class="table bg-white"><thead><tr><th>Date</th><th>Item</th><th>Qty</th><th>Cost</th></tr></thead><tbody id="purTable"></tbody></table>
            </div>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // DATA STORE
        const db = { items:[], invoices:[], customers:[], suppliers:[], expenses:[], jobs:[], purchases:[] };
        let posCart = [];
        let currentInvId = null;

        // INIT
        async function init() {
            const types = ['items','invoices','customers','suppliers','expenses','jobs','purchases'];
            for(let t of types) {
                try {
                    let r = await fetch(`api.php?action=${t}`);
                    db[t] = await r.json();
                } catch(e) { db[t] = []; }
            }
            if(!db.customers.length) db.customers.push({id:1, name:'Walk-in', phone:'0000'});
            renderDashboard();
            renderInvList();
            setupBuilder();
        }
        init();

        // NAV
        function nav(id) {
            document.querySelectorAll('.module').forEach(e => e.classList.remove('active'));
            document.getElementById(id).classList.add('active');
            document.getElementById('pageTitle').innerText = id.toUpperCase();
            if(id === 'pos') renderPos();
            if(id === 'inventory') renderInventory();
            if(id === 'expenses') renderExpenses();
            if(id === 'people') renderPeople();
            if(id === 'jobs') renderJobs();
            if(id === 'purchases') renderPurchases();
        }

        // --- INVOICE BUILDER ---
        function setupBuilder() {
            const sel = document.getElementById('bCust');
            sel.innerHTML = db.customers.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
            document.getElementById('bDate').valueAsDate = new Date();
            document.getElementById('bNo').value = "INV-" + (Date.now().toString().slice(-6));
            addInvRow();
        }

        function resetBuilder() {
            document.getElementById('bRows').innerHTML = '';
            document.getElementById('bNo').value = "INV-" + (Date.now().toString().slice(-6));
            document.getElementById('bPaid').value = 0;
            document.getElementById('bDisc').value = 0;
            document.getElementById('bNotes').value = '';
            addInvRow();
            calcInvTotals();
        }

        function addInvRow(item = null) {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td><input type="text" class="form-control i-name" list="itemList" placeholder="Item Name" value="${item ? item.name : ''}" onchange="fillPrice(this)"></td>
                <td><input type="number" class="form-control i-qty" value="${item ? item.qty : 1}" oninput="calcInvTotals()"></td>
                <td><input type="number" class="form-control i-rate" value="${item ? item.rate : 0}" oninput="calcInvTotals()"></td>
                <td><input type="number" class="form-control i-tax" value="${item ? item.tax : 0}" oninput="calcInvTotals()" placeholder="%"></td>
                <td class="fw-bold text-end i-total">0.00</td>
                <td><i class="fas fa-times text-danger" style="cursor:pointer" onclick="this.closest('tr').remove();calcInvTotals()"></i></td>
            `;
            document.getElementById('bRows').appendChild(tr);
            
            // Datalist for autocomplete
            let dl = document.getElementById('itemList');
            if(!dl) {
                dl = document.createElement('datalist'); dl.id="itemList";
                document.body.appendChild(dl);
            }
            dl.innerHTML = db.items.map(i => `<option value="${i.name}" data-price="${i.price}">`).join('');
            calcInvTotals();
        }

        function fillPrice(inp) {
            const val = inp.value;
            const item = db.items.find(i => i.name === val);
            if(item) {
                const row = inp.closest('tr');
                row.querySelector('.i-rate').value = item.price;
                calcInvTotals();
            }
        }

        function calcInvTotals() {
            let sub = 0, tax = 0;
            document.querySelectorAll('#bRows tr').forEach(tr => {
                const q = parseFloat(tr.querySelector('.i-qty').value) || 0;
                const r = parseFloat(tr.querySelector('.i-rate').value) || 0;
                const t = parseFloat(tr.querySelector('.i-tax').value) || 0;
                const rowVal = q * r;
                const rowTax = rowVal * (t/100);
                tr.querySelector('.i-total').innerText = (rowVal + rowTax).toFixed(2);
                sub += rowVal;
                tax += rowTax;
            });
            
            const disc = parseFloat(document.getElementById('bDisc').value) || 0;
            const paid = parseFloat(document.getElementById('bPaid').value) || 0;
            const grand = sub + tax - disc;
            const bal = grand - paid;

            document.getElementById('bSub').innerText = sub.toFixed(2);
            document.getElementById('bTax').innerText = tax.toFixed(2);
            document.getElementById('bTotal').innerText = grand.toFixed(2);
            document.getElementById('bBal').innerText = bal.toFixed(2);
        }

        async function saveInvoice() {
            const custId = document.getElementById('bCust').value;
            const cust = db.customers.find(c => c.id == custId);
            
            const items = [];
            document.querySelectorAll('#bRows tr').forEach(tr => {
                items.push({
                    name: tr.querySelector('.i-name').value,
                    qty: parseFloat(tr.querySelector('.i-qty').value),
                    rate: parseFloat(tr.querySelector('.i-rate').value),
                    tax: parseFloat(tr.querySelector('.i-tax').value),
                    total: parseFloat(tr.querySelector('.i-total').innerText)
                });
            });

            const inv = {
                id: document.getElementById('bNo').value,
                date: document.getElementById('bDate').value,
                due: document.getElementById('bDue').value,
                customer: cust,
                items: items,
                sub: parseFloat(document.getElementById('bSub').innerText),
                taxTotal: parseFloat(document.getElementById('bTax').innerText),
                discount: parseFloat(document.getElementById('bDisc').value),
                total: parseFloat(document.getElementById('bTotal').innerText),
                paid: parseFloat(document.getElementById('bPaid').value),
                notes: document.getElementById('bNotes').value
            };
            inv.balance = inv.total - inv.paid;
            inv.status = inv.balance <= 0 ? 'Paid' : (inv.paid > 0 ? 'Partial' : 'Unpaid');

            // Update or Add
            const existIdx = db.invoices.findIndex(x => x.id === inv.id);
            if(existIdx > -1) db.invoices[existIdx] = inv;
            else db.invoices.unshift(inv);

            await saveData('invoices');
            renderInvList();
            renderDashboard();
            viewInvoice(inv);
        }

        function viewInvoice(inv) {
            nav('viewer');
            const statusClass = inv.status === 'Paid' ? 'status-paid' : 'status-unpaid';
            const rows = inv.items.map(i => `
                <tr>
                    <td><strong>${i.name}</strong></td>
                    <td>${i.qty}</td>
                    <td>${i.rate}</td>
                    <td>${i.tax}%</td>
                    <td class="text-end fw-bold">${i.total.toFixed(2)}</td>
                </tr>
            `).join('');

            document.getElementById('printArea').innerHTML = `
                <div class="status-stamp ${statusClass}">${inv.status}</div>
                <div class="inv-header">
                    <div>
                        <div class="inv-logo">ARHAM <span style="color:var(--cyan)">ERP</span></div>
                        <p class="m-0 text-muted">Printing & Packaging Solutions</p>
                        <p class="m-0 small">Jalalpur Jattan, Pakistan</p>
                    </div>
                    <div class="inv-meta">
                        <h1>INVOICE</h1>
                        <div><strong># ${inv.id}</strong></div>
                        <div>Date: ${inv.date}</div>
                        ${inv.due ? `<div class="text-danger">Due: ${inv.due}</div>` : ''}
                    </div>
                </div>

                <div class="inv-grid">
                    <div class="inv-to">
                        <h5>Bill To</h5>
                        <h4 class="m-0 fw-bold">${inv.customer.name}</h4>
                        <div class="text-muted">${inv.customer.phone}</div>
                    </div>
                </div>

                <table class="inv-table">
                    <thead><tr><th>Description</th><th>Qty</th><th>Rate</th><th>Tax</th><th class="text-end">Amount</th></tr></thead>
                    <tbody>${rows}</tbody>
                </table>

                <div class="inv-total-box">
                    <div class="inv-row"><span>Subtotal</span> <span>${inv.sub.toFixed(2)}</span></div>
                    <div class="inv-row"><span>Tax</span> <span>${inv.taxTotal.toFixed(2)}</span></div>
                    <div class="inv-row"><span>Discount</span> <span>-${inv.discount.toFixed(2)}</span></div>
                    <div class="inv-row final"><span>Total</span> <span>${inv.total.toFixed(2)}</span></div>
                    <div class="inv-row text-success"><span>Paid</span> <span>${inv.paid.toFixed(2)}</span></div>
                    <div class="inv-row text-danger fw-bold"><span>Balance Due</span> <span>${inv.balance.toFixed(2)}</span></div>
                </div>

                <div style="margin-top:50px; border-top:1px solid #ddd; padding-top:10px">
                    <h6 class="fw-bold">Notes / Terms</h6>
                    <p class="small text-muted">${inv.notes || 'No specific terms.'}</p>
                </div>
            `;
            currentInvId = inv.id;
        }

        // --- DASHBOARD & LISTS ---
        function renderDashboard() {
            // Calculate Stats
            const totalRev = db.invoices.reduce((a,b) => a + (b.paid || b.total), 0); // Cash in hand roughly
            const totalDue = db.invoices.reduce((a,b) => a + (b.balance || 0), 0);
            
            document.getElementById('d_revenue').innerText = "Rs " + totalRev.toLocaleString();
            document.getElementById('d_due').innerText = "Rs " + totalDue.toLocaleString();
            document.getElementById('d_jobs').innerText = db.jobs.filter(j => j.status !== 'Ready').length;
            document.getElementById('d_stock').innerText = db.items.length;

            const dashT = document.getElementById('dashTable');
            dashT.innerHTML = db.invoices.slice(0, 5).map(inv => `
                <tr>
                    <td>${inv.id}</td>
                    <td>${inv.date}</td>
                    <td>${inv.customer.name}</td>
                    <td>${inv.total}</td>
                    <td class="text-danger">${inv.balance}</td>
                    <td><span class="badge bg-${inv.status=='Paid'?'success':'warning'}">${inv.status}</span></td>
                </tr>
            `).join('');
        }

        function renderInvList() {
            const q = document.getElementById('invSearch').value.toLowerCase();
            const filtered = db.invoices.filter(i => 
                i.id.toLowerCase().includes(q) || 
                i.customer.name.toLowerCase().includes(q)
            );
            
            document.getElementById('invList').innerHTML = filtered.map(inv => `
                <tr>
                    <td class="fw-bold">${inv.id}</td>
                    <td>${inv.date}</td>
                    <td>${inv.customer.name}</td>
                    <td>${inv.total.toFixed(2)}</td>
                    <td class="text-success">${inv.paid.toFixed(2)}</td>
                    <td class="text-danger fw-bold">${inv.balance.toFixed(2)}</td>
                    <td><span class="badge bg-${inv.status=='Paid'?'success':(inv.status=='Partial'?'info':'danger')}">${inv.status}</span></td>
                    <td class="text-end">
                        <button class="btn btn-sm btn-light border" onclick='loadInvoiceForEdit(${JSON.stringify(inv)})'><i class="fas fa-edit"></i></button>
                        <button class="btn btn-sm btn-primary" onclick='viewInvoice(${JSON.stringify(inv)})'><i class="fas fa-eye"></i></button>
                    </td>
                </tr>
            `).join('');
        }

        function loadInvoiceForEdit(inv) {
            nav('builder');
            document.getElementById('bNo').value = inv.id;
            document.getElementById('bDate').value = inv.date;
            document.getElementById('bDue').value = inv.due || '';
            document.getElementById('bCust').value = inv.customer.id;
            document.getElementById('bNotes').value = inv.notes || '';
            document.getElementById('bPaid').value = inv.paid;
            document.getElementById('bDisc').value = inv.discount;
            
            const tb = document.getElementById('bRows');
            tb.innerHTML = '';
            inv.items.forEach(item => addInvRow(item));
            calcInvTotals();
        }

        // --- POS ---
        function renderPos() {
            document.getElementById('posGrid').innerHTML = db.items.map(i => `
                <div class="p-card" onclick="addToPos(${i.id})">
                    <div class="fw-bold text-truncate">${i.name}</div>
                    <div class="text-primary fw-bold">Rs ${i.price}</div>
                    <div class="small text-muted">Stock: ${i.stock}</div>
                </div>
            `).join('');
            
            // Cust Select
            const s = document.getElementById('posCust');
            if(s.options.length === 0) s.innerHTML = db.customers.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
        }

        function addToPos(id) {
            const item = db.items.find(i => i.id == id);
            const ex = posCart.find(x => x.id == id);
            if(ex) ex.qty++; else posCart.push({...item, qty:1});
            updatePosCart();
        }

        function updatePosCart() {
            let t = 0;
            document.getElementById('posCart').innerHTML = posCart.map((c,i) => {
                t += c.price * c.qty;
                return `<div class="d-flex justify-content-between border-bottom py-2">
                    <div>${c.name} <small>x${c.qty}</small></div>
                    <div>${c.price*c.qty} <i class="fas fa-times text-danger ms-2" style="cursor:pointer" onclick="posCart.splice(${i},1);updatePosCart()"></i></div>
                </div>`;
            }).join('');
            document.getElementById('posTotal').innerText = t;
            document.getElementById('posCount').innerText = posCart.length;
        }

        function processPOS() {
            if(!posCart.length) return alert("Cart empty");
            // Convert POS sale to Invoice
            const custId = document.getElementById('posCust').value;
            const cust = db.customers.find(c => c.id == custId);
            const total = parseFloat(document.getElementById('posTotal').innerText);
            
            const inv = {
                id: "POS-" + Date.now(),
                date: new Date().toISOString().split('T')[0],
                customer: cust,
                items: posCart.map(c => ({name: c.name, qty: c.qty, rate: c.price, tax:0, total: c.price*c.qty})),
                sub: total, taxTotal: 0, discount: 0, total: total, paid: total, balance: 0, status: 'Paid', notes: 'POS Sale'
            };
            
            db.invoices.unshift(inv);
            
            // Deduct Stock
            posCart.forEach(c => {
                const i = db.items.find(x => x.id == c.id);
                if(i) i.stock -= c.qty;
            });
            
            saveData('invoices');
            saveData('items');
            posCart = []; updatePosCart();
            viewInvoice(inv);
        }

        // --- SHARED API ---
        async function saveData(type) {
            await fetch(`api.php?action=${type}`, { method: 'POST', body: JSON.stringify(db[type]) });
        }

        // --- BASIC RENDERERS ---
        function renderInventory() {
            document.getElementById('invTable').innerHTML = db.items.map(i => `<tr><td>${i.id}</td><td>${i.name}</td><td>${i.category}</td><td>${i.stock}</td><td>${i.price}</td></tr>`).join('');
        }
        function renderExpenses() {
            document.getElementById('expList').innerHTML = db.expenses.map(e => `<li class="list-group-item d-flex justify-content-between"><span>${e.desc}</span> <span class="fw-bold text-danger">-${e.amt}</span></li>`).join('');
        }
        function renderPeople() {
            document.getElementById('custList').innerHTML = db.customers.map(c => `<li class="list-group-item">${c.name} <span class="text-muted small">${c.phone}</span></li>`).join('');
            document.getElementById('suppList').innerHTML = db.suppliers.map(s => `<li class="list-group-item">${s.name}</li>`).join('');
        }
        function renderJobs() {
            document.getElementById('jobBoard').innerHTML = db.jobs.map(j => `
                <div class="col-md-4">
                    <div class="builder-card p-3 border-start border-5 border-${j.status=='Pending'?'warning':'success'}">
                        <div class="d-flex justify-content-between mb-2"><span class="badge bg-secondary">${j.status}</span> <small>${j.date}</small></div>
                        <h5 class="fw-bold">${j.client}</h5>
                        <p class="small text-muted mb-2">${j.desc}</p>
                        <select class="form-select form-select-sm" onchange="updateJob(${j.id}, this.value)">
                            <option>Pending</option><option>Designing</option><option>Printing</option><option>Ready</option>
                        </select>
                    </div>
                </div>`).join('');
        }
        function renderPurchases() {
            const s = document.getElementById('purItem');
            if(!s.options.length) s.innerHTML = db.items.map(i => `<option value="${i.id}">${i.name}</option>`).join('');
            document.getElementById('purTable').innerHTML = db.purchases.map(p => `<tr><td>${p.date}</td><td>${p.itemName}</td><td>${p.qty}</td><td>${p.cost}</td></tr>`).join('');
        }

        // --- UTILS ---
        async function updateJob(id, status) {
            const j = db.jobs.find(x => x.id == id);
            if(j) { j.status = status; await saveData('jobs'); renderJobs(); }
        }
        async function promptAddItem() {
            const n = prompt("Item Name"); const p = prompt("Price"); const s = prompt("Stock");
            if(n) { db.items.push({id:Date.now(), name:n, category:'General', price:p, stock:s}); await saveData('items'); renderInventory(); }
        }
        async function addExpense(e) {
            e.preventDefault();
            const d = document.getElementById('expDesc').value; const a = document.getElementById('expAmt').value;
            db.expenses.unshift({desc:d, amt:a, date: new Date().toISOString().split('T')[0]});
            await saveData('expenses'); e.target.reset(); renderExpenses();
        }
        async function addPurchase(e) {
            e.preventDefault();
            const id = document.getElementById('purItem').value;
            const q = parseInt(document.getElementById('purQty').value);
            const c = document.getElementById('purCost').value;
            const item = db.items.find(x => x.id == id);
            
            db.purchases.unshift({date: new Date().toISOString().split('T')[0], itemName: item.name, qty:q, cost:c});
            item.stock = parseInt(item.stock) + q;
            
            await saveData('purchases'); await saveData('items');
            e.target.reset(); renderPurchases(); alert("Stock Added");
        }
        function promptAddPerson(type) {
            const n = prompt("Name"); const p = prompt("Phone");
            if(n) {
                db[type === 'cust' ? 'customers' : 'suppliers'].push({id:Date.now(), name:n, phone:p});
                saveData(type === 'cust' ? 'customers' : 'suppliers');
                alert("Added. Refresh to see in lists.");
            }
        }
        function shareWhatsapp() {
            const inv = db.invoices.find(x => x.id == currentInvId);
            const msg = `*INVOICE # ${inv.id}*%0aTo: ${inv.customer.name}%0aTotal: ${inv.total}%0aDue: ${inv.balance}%0a%0aThank you!`;
            window.open(`https://wa.me/${inv.customer.phone}?text=${msg}`, '_blank');
        }
        async function newJob() {
            const c = prompt("Client"); const d = prompt("Desc");
            if(c) { db.jobs.unshift({id:Date.now(), client:c, desc:d, status:'Pending', date: new Date().toISOString().split('T')[0]}); await saveData('jobs'); renderJobs(); }
        }
    </script>
</body>
</html>